import { User, Nurse, Evaluation, Audit } from '@/types';

const STORAGE_KEYS = {
  CURRENT_USER: 'adaa_current_user',
  USERS: 'adaa_users',
  NURSES: 'adaa_nurses',
  EVALUATIONS: 'adaa_evaluations',
  AUDITS: 'adaa_audits',
};

// User Management
export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  return user ? JSON.parse(user) : null;
};

export const setCurrentUser = (user: User | null): void => {
  if (user) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
};

export const getAllUsers = (): User[] => {
  const users = localStorage.getItem(STORAGE_KEYS.USERS);
  return users ? JSON.parse(users) : [];
};

export const addUser = (user: User): void => {
  const users = getAllUsers();
  users.push(user);
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
};

export const initializeDefaultUsers = (): void => {
  const users = getAllUsers();
  if (users.length === 0) {
    const defaultUsers: User[] = [
      {
        id: '1',
        email: 'manager@adaa.com',
        name: 'مدير الوحدة',
        role: 'manager',
      },
      {
        id: '2',
        email: 'supervisor@adaa.com',
        name: 'المشرف الأول',
        role: 'supervisor',
      },
    ];
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaultUsers));
  }
};

// Nurses Management
export const getAllNurses = (): Nurse[] => {
  const nurses = localStorage.getItem(STORAGE_KEYS.NURSES);
  return nurses ? JSON.parse(nurses) : [];
};

export const getActiveNurses = (): Nurse[] => {
  return getAllNurses().filter(nurse => nurse.is_active);
};

export const getNurseById = (id: string): Nurse | undefined => {
  return getAllNurses().find(nurse => nurse.id === id);
};

export const addNurse = (nurse: Nurse): void => {
  const nurses = getAllNurses();
  nurses.push(nurse);
  localStorage.setItem(STORAGE_KEYS.NURSES, JSON.stringify(nurses));
};

export const updateNurse = (id: string, updates: Partial<Nurse>): void => {
  const nurses = getAllNurses();
  const index = nurses.findIndex(n => n.id === id);
  if (index !== -1) {
    nurses[index] = { ...nurses[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.NURSES, JSON.stringify(nurses));
  }
};

export const deleteNurse = (id: string): void => {
  const nurses = getAllNurses().filter(n => n.id !== id);
  localStorage.setItem(STORAGE_KEYS.NURSES, JSON.stringify(nurses));
};

export const initializeDefaultNurses = (): void => {
  const nurses = getAllNurses();
  if (nurses.length === 0) {
    const defaultNurses: Nurse[] = [
      { id: '1', name: 'أحمد محمد', is_active: true },
      { id: '2', name: 'فاطمة علي', is_active: true },
      { id: '3', name: 'محمد حسن', is_active: true },
      { id: '4', name: 'نورا إبراهيم', is_active: true },
      { id: '5', name: 'سارة أحمد', is_active: true },
    ];
    localStorage.setItem(STORAGE_KEYS.NURSES, JSON.stringify(defaultNurses));
  }
};

// Evaluations Management
export const getAllEvaluations = (): Evaluation[] => {
  const evaluations = localStorage.getItem(STORAGE_KEYS.EVALUATIONS);
  return evaluations ? JSON.parse(evaluations) : [];
};

export const getEvaluationById = (id: string): Evaluation | undefined => {
  return getAllEvaluations().find(ev => ev.id === id);
};

export const getEvaluationsByNurse = (nurseId: string): Evaluation[] => {
  return getAllEvaluations().filter(ev => ev.nurse_id === nurseId);
};

export const getEvaluationsBySupervisor = (supervisorId: string): Evaluation[] => {
  return getAllEvaluations().filter(ev => ev.supervisor_id === supervisorId);
};

export const addEvaluation = (evaluation: Evaluation): void => {
  const evaluations = getAllEvaluations();
  evaluations.push(evaluation);
  localStorage.setItem(STORAGE_KEYS.EVALUATIONS, JSON.stringify(evaluations));
};

// Audits Management
export const getAllAudits = (): Audit[] => {
  const audits = localStorage.getItem(STORAGE_KEYS.AUDITS);
  return audits ? JSON.parse(audits) : [];
};

export const getAuditsByEvaluation = (evaluationId: string): Audit[] => {
  return getAllAudits().filter(audit => audit.evaluation_id === evaluationId);
};

export const addAudit = (audit: Audit): void => {
  const audits = getAllAudits();
  audits.push(audit);
  localStorage.setItem(STORAGE_KEYS.AUDITS, JSON.stringify(audits));
};

// Initialize all defaults
export const initializeStorage = (): void => {
  initializeDefaultUsers();
  initializeDefaultNurses();
};

export type UserRole = 'manager' | 'supervisor';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

export interface Nurse {
  id: string;
  name: string;
  photo_url?: string;
  is_active: boolean;
}

export type EvaluationType = 'weekly' | 'monthly';

export interface Evaluation {
  id: string;
  nurse_id: string;
  supervisor_id: string;
  type: EvaluationType;
  evaluation_date: string;
  scores: Record<string, number>;
  notes: Record<string, string>;
  final_score: number;
}

export interface Audit {
  id: string;
  evaluation_id: string;
  auditor_id: string;
  is_match: boolean;
  auditor_notes: string;
  decision: string;
}

export interface EvaluationItem {
  id: number;
  text: string;
  category: 'technical' | 'behavioral' | 'care' | 'initiative';
  weight?: number;
}

import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { LogOut, Users, TrendingUp, TrendingDown, BarChart3, FileText } from 'lucide-react';
import { getAllEvaluations, getAllNurses } from '@/lib/storage';
import { getNurseAverageScore } from '@/lib/calculations';

const ManagerDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const evaluations = getAllEvaluations();
  const nurses = getAllNurses();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Calculate KPIs
  const thisMonthEvaluations = evaluations.filter(e => {
    const date = new Date(e.evaluation_date);
    const now = new Date();
    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
  });

  const overallAverage = evaluations.length > 0
    ? evaluations.reduce((sum, e) => sum + e.final_score, 0) / evaluations.length
    : 0;

  // Get top and bottom performers
  const nursePerformance = nurses.map(nurse => {
    const nurseEvals = evaluations.filter(e => e.nurse_id === nurse.id);
    return {
      ...nurse,
      average: getNurseAverageScore(nurseEvals),
      evaluationCount: nurseEvals.length,
    };
  }).filter(n => n.evaluationCount > 0);

  const topPerformers = nursePerformance.sort((a, b) => b.average - a.average).slice(0, 3);
  const bottomPerformers = nursePerformance.sort((a, b) => a.average - b.average).slice(0, 3);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container max-w-7xl mx-auto p-4 space-y-6">
        {/* Header */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-3xl">لوحة التحكم</CardTitle>
              <CardDescription>مرحباً {user?.name}</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </CardHeader>
        </Card>

        {/* KPIs */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">متوسط الأداء</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">
                {overallAverage.toFixed(1)}%
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                من جميع التقييمات
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">التقييمات هذا الشهر</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">
                {thisMonthEvaluations.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                تقييم مكتمل
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">فريق التمريض</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">
                {nurses.filter(n => n.is_active).length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                ممرض نشط
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Top and Bottom Performers */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-success">
                <TrendingUp className="h-5 w-5" />
                أفضل 3 ممرضين أداءً
              </CardTitle>
            </CardHeader>
            <CardContent>
              {topPerformers.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">لا توجد بيانات كافية</p>
              ) : (
                <div className="space-y-3">
                  {topPerformers.map((nurse, index) => (
                    <div
                      key={nurse.id}
                      className="flex items-center justify-between p-3 border rounded-lg bg-success/5 hover:bg-success/10 transition-colors cursor-pointer"
                      onClick={() => navigate(`/manager/nurses/${nurse.id}`)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-success text-success-foreground rounded-full flex items-center justify-center font-bold">
                          {index + 1}
                        </div>
                        <span className="font-medium">{nurse.name}</span>
                      </div>
                      <span className="text-xl font-bold text-success">
                        {nurse.average.toFixed(1)}%
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive">
                <TrendingDown className="h-5 w-5" />
                يحتاجون للدعم
              </CardTitle>
            </CardHeader>
            <CardContent>
              {bottomPerformers.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">لا توجد بيانات كافية</p>
              ) : (
                <div className="space-y-3">
                  {bottomPerformers.map((nurse) => (
                    <div
                      key={nurse.id}
                      className="flex items-center justify-between p-3 border rounded-lg bg-destructive/5 hover:bg-destructive/10 transition-colors cursor-pointer"
                      onClick={() => navigate(`/manager/nurses/${nurse.id}`)}
                    >
                      <span className="font-medium">{nurse.name}</span>
                      <span className="text-xl font-bold text-destructive">
                        {nurse.average.toFixed(1)}%
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>إجراءات سريعة</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2">
            <Button
              variant="outline"
              className="h-16 text-lg justify-start"
              onClick={() => navigate('/manager/nurses')}
            >
              <Users className="mr-2 h-5 w-5" />
              إدارة فريق التمريض
            </Button>
            <Button
              variant="outline"
              className="h-16 text-lg justify-start"
              onClick={() => navigate('/manager/audits')}
            >
              <FileText className="mr-2 h-5 w-5" />
              المراجعات العشوائية
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ManagerDashboard;

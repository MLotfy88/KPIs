import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { Plus, FileText, LogOut } from 'lucide-react';
import { getEvaluationsBySupervisor } from '@/lib/storage';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

const SupervisorDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const recentEvaluations = getEvaluationsBySupervisor(user?.id || '').slice(-5).reverse();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <div>
              <CardTitle className="text-2xl">مرحباً {user?.name}</CardTitle>
              <CardDescription>جاهز لبدء تقييم جديد؟</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => navigate('/supervisor/evaluate')}
              size="lg"
              className="w-full h-16 text-lg"
            >
              <Plus className="mr-2 h-5 w-5" />
              ابدأ تقييم جديد
            </Button>
          </CardContent>
        </Card>

        {/* Recent Evaluations */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              آخر التقييمات
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentEvaluations.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">
                لم تقم بأي تقييمات بعد
              </p>
            ) : (
              <div className="space-y-3">
                {recentEvaluations.map((evaluation) => (
                  <div
                    key={evaluation.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div>
                      <p className="font-medium">
                        {evaluation.type === 'weekly' ? 'تقييم أسبوعي' : 'تقييم شهري'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(evaluation.evaluation_date), 'PPP', { locale: ar })}
                      </p>
                    </div>
                    <div className="text-left">
                      <p className="text-2xl font-bold text-primary">
                        {evaluation.final_score.toFixed(1)}
                        {evaluation.type === 'monthly' ? '%' : '/5'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SupervisorDashboard;
